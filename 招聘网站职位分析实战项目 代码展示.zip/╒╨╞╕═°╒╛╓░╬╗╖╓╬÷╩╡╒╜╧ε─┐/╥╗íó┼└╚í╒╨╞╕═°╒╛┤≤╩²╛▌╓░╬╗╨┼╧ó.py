import urllib.request
from urllib.parse import *
from bs4 import BeautifulSoup
import string
import random
import os
headers = [
    "Mozilla/5.0 (Windows NT 6.1; Win64; rv:27.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
    "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:27.0) Gecko/20100101 Firfox/27.0"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
    "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:10.0) Gecko/20100101 Firfox/10.0"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/21.0.1180.110 Safari/537.36"
    "Mozilla/5.0 (X11; Ubuntu; Linux i686 rv:10.0) Gecko/20100101 Firfox/27.0"
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/34.0.1838.2 Safari/537.36"
    "Mozilla/5.0 (X11; Ubuntu; Linux i686 rv:27.0) Gecko/20100101 Firfox/27.0"
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36'
    ]
def get_content(url, headers):
    #@url：需要登录的网址
    #@headers：模拟的登陆的终端
    #*********************模拟登陆获取网址********************

    random_header = random.choice(headers)
    req = urllib.request.Request(url)
    req.add_header("User-Agent", random_header)
    req.add_header("Host", "192.168.1.150:40000")
    try:
        html = urllib.request.urlopen(req)
        contents = html.read()
        if isinstance(contents, bytes):
            contents = contents.decode('utf-8')
        else:
            print('service mysql restart')
        return (contents)
    except Exception as e:
        print(e)
def get_links_from(page):
    #@page：表示第几页信息
    #@urls：所有列表的超链接，即子页网址
    #****************此网站需要模拟登陆**********************
    #返回全部子网页地址
    urls = []
    for i in range(1,page):
        url='http://192.168.1.150:40000/wuyou/{0}'.format(i)
        url = quote(url, safe=string.printable)
        info = get_content(url, headers)
        soup = BeautifulSoup(info, "lxml")
        link_urls = soup.select('div.dw_table div.el span.t2 a')
        for url in link_urls:
            oneurl="http://192.168.1.150:40000"+url.get('href')
            urls.append(oneurl)
    # print(urls)
    return (urls)
def get_recuite_info(page):
    #获取网页信息
    urls = get_links_from(page)
    path='/data/zhaopin/'
    if os.path.exists(path)==False:
        os.makedirs(path)
    for url in urls:
        print(url)
        file=url.split('/')[-1]
        print(file)
        str=url.split('/')[2].split('.')[0]
        html = get_content(url, headers)
        if html!=None and file!='':
            with open(path+file,'w') as f:
                f.write(html)
#*********************获取信息***************************
if __name__ == '__main__':
    get_recuite_info(20)