import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.font_manager as fm

fontPath = "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"
font = fm.FontProperties(fname=fontPath, size=10)

data = pd.read_csv('/data/python_pj3/bigdata')
print(data.shape)
print(data.columns)

# 将部分销售类职位合并
data.loc[((data['职位类别'] == '客户代表') | (data['职位类别'] == '电话销售') | (data['职位类别'] == '大客户销售代表')), '职位类别'] = '销售代表'

# 处理月工资数据
monthly_salary = data['月工资'].str.strip('元/月').str.split('-', expand=True)
monthly_salary.columns = ['月工资_min', '月工资_max']
data['月工资_min'] = monthly_salary['月工资_min']
data['月工资_max'] = monthly_salary['月工资_max']

# 处理月工资特殊值
data.loc[(data['月工资_min'] == '面议'), '月工资_min'] = 0
data.loc[(data['月工资_min'] == '1000元/月以下'), '月工资_min'] = 1
data.loc[(data['月工资_min'] == '100000元/月以上'), '月工资_min'] = 7
data.loc[(data['月工资_max'].isnull()), '月工资_max'] = 0

# 转换月工资数据类型为整数
data['月工资_min'] = data['月工资_min'].astype(int)
data['月工资_max'] = data['月工资_max'].astype(int)

# 计算月工资均值
monthly_salary_mean = (data['月工资_min'] + data['月工资_max']) / 2

# 根据月工资范围重新赋值月工资
data.loc[((data['月工资_min'] == 0) & (data['月工资_max'] == 0) & (data['月工资'].notnull())), '月工资'] = 0
data.loc[((data['月工资_min'] == 1) & (data['月工资_max'] == 0) & (data['月工资'].notnull())), '月工资'] = 1
data.loc[((data['月工资_min'] < 6000) & (data['月工资_min'] > 8)), '月工资'] = 1
data.loc[((((data['月工资_min'] >= 6000) & (data['月工资_max'] <= 8000)) | ((6000 < monthly_salary_mean) & (monthly_salary_mean < 8000))) & (data['月工资'].notnull())), '月工资'] = 2
data.loc[((((data['月工资_min'] >= 8000) & (data['月工资_max'] <= 10000)) | ((8000 <= monthly_salary_mean) & (monthly_salary_mean < 10000))) & (data['月工资'].notnull())), '月工资'] = 3
data.loc[((((data['月工资_min'] >= 10000) & (data['月工资_max'] <= 20000)) | ((10000 <= monthly_salary_mean) & (monthly_salary_mean < 20000))) & (data['月工资'].notnull())), '月工资'] = 4
data.loc[((((data['月工资_min'] >= 20000) & (data['月工资_max'] <= 30000)) | ((20000 <= monthly_salary_mean) & (monthly_salary_mean < 30000))) & (data['月工资'].notnull())), '月工资'] = 5
data.loc[((((data['月工资_min'] >= 30000) & (data['月工资_max'] <= 50000)) | ((30000 <= monthly_salary_mean) & (monthly_salary_mean < 50000))) & (data['月工资'].notnull())), '月工资'] = 6
data.loc[(((data['月工资_min'] >= 50000) | (50000 <= monthly_salary_mean)) & (data['月工资'].notnull())), '月工资'] = 7
data.loc[((data['月工资_min'] == 7) & (data['月工资_max'] == 0) & (data['月工资'].notnull())), '月工资'] = 7

print(data['月工资'].value_counts(sort=False))

# 提取城市信息（假设工作地点格式为"城市-区域"）
data['城市'] = data['工作地点'].str.split('-', expand=True)[0]

# 不同城市的平均薪资
avg_salary_by_city = data.groupby('城市')['月工资'].mean()
print("不同城市的平均薪资：")
print(avg_salary_by_city)

# 不同城市的薪资中位数
median_salary_by_city = data.groupby('城市')['月工资'].median()
print("不同城市的薪资中位数：")
print(median_salary_by_city)

# 绘制不同城市平均薪资柱状图
plt.figure()
avg_salary_by_city.plot(kind='bar', color='steelblue')
plt.title('不同城市的平均薪资', fontproperties=font)
plt.xlabel('城市', fontproperties=font)
plt.ylabel('平均月工资', fontproperties=font)
plt.xticks(rotation=45, fontproperties=font)

# 绘制箱线图展示不同城市的薪资分布
plt.figure()
sns.boxplot(x=data['城市'], y=data['月工资'])
plt.title('不同城市的薪资分布', fontproperties=font)
plt.xlabel('城市', fontproperties=font)
plt.ylabel('月工资', fontproperties=font)
plt.xticks(rotation=45, fontproperties=font)

plt.show()
