import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer, ENGLISH_STOP_WORDS
from sklearn.cluster import KMeans

# 读取CSV文件数据到DataFrame
data=pd.read_csv('/data/python_pj6/bigdata',header=None,names=[ '人数', '公司名称', '公司地址', '公司性质', '公司网址', '公司行业', '公司规模',
       '发布日期', '岗位描述', '工作名称', '工作地点', '工作性质', '最低学历', '月工资', '福利', '经验', '网址',
       '职位类别'])
data=data[1:]

# 获取岗位类别列的数据
job_categories = data['工作名称'].tolist()

# 读取中文停用词表文件，将停用词存为列表
stop_words = []
with open('/data/python_pj6/china_stopword.txt', 'r', encoding='utf-8') as f:
    for line in f:
        stop_word = line.strip()  # 去除每行的换行符等空白字符
        stop_words.append(stop_word)

# 创建词袋模型对象，设置去除中文停用词参数
vectorizer = CountVectorizer(stop_words=stop_words)

# 将岗位类别名称列表转换为向量矩阵
X = vectorizer.fit_transform(job_categories)

# 设定聚类数量
n_clusters = 6

# 创建K-Means聚类器对象
kmeans = KMeans(n_clusters=n_clusters)
kmeans.fit(X)

# 获取聚类结果，每个岗位类别对应的聚类标签
labels = kmeans.labels_

# 收集每个聚类组下的岗位类别信息，用于保存结果
cluster_results = {}
for i in range(n_clusters):
    cluster_results[i] = [job_categories[j] for j in range(len(job_categories)) if labels[j] == i]

# 将聚类结果保存到文本文件中
with open('/data/python_pj6/cluster_result.csv', 'w', encoding='utf-8') as f:
    for cluster_id, categories in cluster_results.items():
        f.write("聚类组 {} 中的岗位类别：".format(cluster_id))
        for category in categories:
            f.write(category + "\n")
        f.write("\n")
