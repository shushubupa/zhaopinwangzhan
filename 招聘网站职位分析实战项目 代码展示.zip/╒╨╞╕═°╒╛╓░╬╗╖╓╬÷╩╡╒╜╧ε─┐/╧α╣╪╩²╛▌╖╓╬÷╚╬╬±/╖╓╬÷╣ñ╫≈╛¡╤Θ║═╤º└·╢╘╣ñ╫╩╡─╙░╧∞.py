import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.font_manager as fm

fontPath ="/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"
font = fm.FontProperties(fname=fontPath, size=10)

#加载数据
data=pd.read_csv('/data/python_pj4/bigdata',header=None,names=[ '人数', '公司名称', '公司地址', '公司性质', '公司网址', '公司行业', '公司规模',
       '发布日期', '岗位描述', '工作名称', '工作地点', '工作性质', '最低学历', '月工资', '福利', '经验', '网址',
       '职位类别'])
df=data[1:]

# 假设df是包含薪资数据的原始数据框
def process_salary(salary_str):
    if '-' in salary_str:
        # 提取薪资范围的下限和上限
        salary_min, salary_max = salary_str.split('-')
        salary_min = int(salary_min)  # 去除 "元/月" 中的 "元" 和 "/月"
        salary_max = int(salary_max[:-3])
        # 可以根据需要选择计算平均值、中位数或其他方式来表示该范围薪资
        # 这里以平均值为例
        return (salary_min + salary_max) / 2

# 对薪资列进行预处理，将字符串形式的薪资转换为数值形式
df['月工资'] = df['月工资'].apply(process_salary)

# 使用groupby方法按照工作经验分组，并计算每组的平均薪资和中位数薪资
work_experience_salary = df.groupby('经验').agg({
    '月工资': ['mean','median']
})
# 重命名列名，让其更清晰直观
work_experience_salary.columns = ['avg_salary','median_salary']
# 按照工作经验进行排序
work_experience_salary = work_experience_salary.sort_index()

# 使用groupby方法按照学历要求分组，并计算每组的平均薪资和中位数薪资
education_salary = df.groupby('最低学历').agg({
   '月工资': ['mean','median']
})
# 重命名列名
education_salary.columns = ['avg_salary','median_salary']
# 按照学历要求进行排序
education_salary = education_salary.sort_index()

# 使用groupby方法按照工作经验和学历要求两个维度进行分组，并计算每组的平均薪资
work_experience_education_salary = df.groupby(['经验', '最低学历']).agg({
   '月工资': ['mean']
})
# 重命名列名
work_experience_education_salary.columns = ['avg_salary']
# 按照工作经验和学历要求进行排序（先按照工作经验，再按照学历要求排序）
work_experience_education_salary = work_experience_education_salary.sort_index()

# 绘制平均薪资与工作经验关系的柱状图
plt.figure(figsize=(10, 6))
g=sns.barplot(x=work_experience_salary.index, y='avg_salary', data=work_experience_salary.reset_index())

# 获取 x 轴刻度标签对象列表
x_tick_labels = g.axes.get_xticklabels()
# 循环遍历每个刻度标签对象，应用字体属性
for label in x_tick_labels:
    label.set_fontproperties(font)

plt.xlabel('工作经验').set_fontproperties(font)
plt.ylabel('平均薪资').set_fontproperties(font)
plt.title('薪资与工作经验的关系').set_fontproperties(font)
plt.xticks(rotation=45)
plt.show()

# 可视化薪资与学历要求的关系
plt.figure(figsize=(10, 6))
g=sns.barplot(x=education_salary.index, y='avg_salary', data=education_salary.reset_index())

# 获取 x 轴刻度标签对象列表
x_tick_labels = g.axes.get_xticklabels()
# 循环遍历每个刻度标签对象，应用字体属性
for label in x_tick_labels:
    label.set_fontproperties(font)

plt.xlabel('学历要求').set_fontproperties(font)
plt.ylabel('平均薪资').set_fontproperties(font)
plt.title('薪资与学历要求的关系').set_fontproperties(font)
plt.xticks(rotation=45)
plt.show()
