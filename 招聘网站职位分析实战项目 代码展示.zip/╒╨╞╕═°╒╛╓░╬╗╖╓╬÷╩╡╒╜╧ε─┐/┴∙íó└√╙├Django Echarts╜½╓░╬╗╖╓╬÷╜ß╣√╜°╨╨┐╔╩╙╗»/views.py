from django.shortcuts import render

# Create your views here.
from web import models
import json
from django.db import connection
import pymysql
from django.shortcuts import render, HttpResponse

def word(request):
    return render(request, 'word_cloud.html')
def word_data(request):
    # select
    # conn = pymysql.connect(host='localhost', user='root', passwd='123456', db='zhilian', port=3306, charset='utf8')
    cur = connection.cursor()
    cur.execute('select * from job_des order by num desc ;')
    data_obj = cur.fetchall()
    data_list = []
    for i in data_obj:
        data_list.append({'name': i[0], 'value': i[1]})
    cur.close()
    connection.close()
    return HttpResponse(json.dumps(data_list))
