#-*- coding:utf-8

'''

preprocess.py
这个文件的作用是做文档预处理，
讲每篇文档，生成相应的token_list
只需执行最后documents_pre_process函数即可。

'''

from nltk.tokenize import WordPunctTokenizer
import traceback
import jieba
from nltk.corpus import stopwords
from nltk.stem.lancaster import LancasterStemmer
from collections import defaultdict
import re

# 分词 - 英文
def tokenize(document):
    try:

        token_list = WordPunctTokenizer().tokenize(document)

        #print("[INFO]: tokenize is finished!")
        return token_list

    except Exception as e:
        print(traceback.print_exc())

# 分词 - 中文
def tokenize_chinese(document):
    try:

        token_list = jieba.cut( document, cut_all=False )

        #print("[INFO]: tokenize_chinese is finished!")
        return token_list

    except Exception as e:
        print(traceback.print_exc())

# 去除停用词 -英文
def filtered_stopwords_en(token_list):
    try:

        token_list_without_stopwords = [ word for word in token_list if word not in stopwords.words("english")]

        #print("[INFO]: filtered_words is finished!")
        return token_list_without_stopwords
    except Exception as e:
        print(traceback.print_exc())

# 去除停用词 - 中文
def filtered_stopwords_ch(token_list,stopwords):
    try:

        token_list_without_stopwords = [word for word in token_list if word not in stopwords]

        # print("[INFO]: filtered_words is finished!")
        return token_list_without_stopwords
    except Exception as e:
        print(traceback.print_exc())


# 去除标点
def filtered_punctuations(token_list):
    try:

        punctuations = ['', '\n', '\t', ',', '.', ':', ';', '?', '(', ')', '[', ']', '&', '!', '*', '@', '#', '$', '%','xa0','，']
        token_list_without_punctuations = [word for word in token_list if word not in punctuations]

        #print("[INFO]: filtered_punctuations is finished!")
        return token_list_without_punctuations

    except Exception as e:
        print(traceback.print_exc())

# 过滤出中 - 英文
def filtered_chinese_english_words(token_list):
    try:
        r1 = re.compile(r'\w')  # 使用正则表达式,筛选[A-Za-z0-9_]
        r2 = re.compile(r'[^\d]')  # 使用正则表达式,筛选[0-9_]
        r4 = re.compile(r'[^_]')
        r3 = re.compile(r'[\u4e00-\u9fa5]')
        token_list = [word.lower() for word in token_list if (r3.match(word) != None) or (r3.match(word) == None and r1.match(word) and r2.match(word) and r4.match(word))]
        # print("[INFO]: filtered_punctuations is finished!")
        return token_list

    except Exception as e:
        print(traceback.print_exc())

# 词干化 -英文
def stemming( filterd_token_list ):
    try:

        st = LancasterStemmer()
        stemming_token_list = [ st.stem(word) for word in filterd_token_list ]

        #print("[INFO]: stemming is finished")
        return stemming_token_list

    except Exception as e:
        print(traceback.print_exc())

# 去除低频单词
def low_frequence_filter( token_list ):
    try:

        word_counter = defaultdict(int)
        for word in token_list:
            word_counter[word] += 1

        threshold = 0
        token_list_without_low_frequence = [ word
                                             for word in token_list
                                             if word_counter[word] > threshold]

        #print "[INFO]: low_frequence_filter is finished!"
        return token_list_without_low_frequence
    except Exception as e:
        print(traceback.print_exc())

"""
功能：预处理
@ document: 文档
@ token_list: 预处理之后文档对应的单词列表
"""
def pre_process( document,ch_stopwords ):
    try:

        # token_list = tokenize(document)
        token_list = tokenize_chinese(document)
        token_list=filtered_chinese_english_words(token_list )
        token_list = filtered_stopwords_ch(token_list, ch_stopwords)
        token_list= filtered_punctuations(token_list)

        #print("[INFO]: pre_process is finished!")
        return token_list

    except Exception as e:
        print(traceback.print_exc())

"""
功能：预处理
@ document: 文档集合
@ token_list: 预处理之后文档集合对应的单词列表
"""
def documents_pre_process( documents,ch_stopwords ):
    try:

        documents_token_list = []
        for document in documents:
            token_list = pre_process(document,ch_stopwords)
            documents_token_list.append(token_list)

        print("[INFO]:documents_pre_process is finished!")
        return documents_token_list

    except Exception as e:
        print(traceback.print_exc())

#-----------------------------------------------------------------------
def test_pre_process(documents,ch_stopwords):

    # documents = ["he,he,he,we are happy!",
    #              "he,he,we are happy!",
    #              "you work!"]
    documents_token_list = []
    for document in documents:
        token_list = pre_process(document,ch_stopwords)
        documents_token_list.append(token_list)

    for token_list in documents_token_list:
        print(token_list)


# test_pre_process()
import pandas as pd
INPUT_PATH = "/data/python_pj6/bigdata"
ch_stopkeyword=[line.strip() for line in open('/data/python_pj6/stopword').readlines()] #加载停用词
data=pd.read_csv(INPUT_PATH)
test_pre_process(data.岗位描述,ch_stopkeyword)
